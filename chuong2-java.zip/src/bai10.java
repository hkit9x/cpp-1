import java.util.Scanner;
public class bai10 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        int a;
        do{
            System.out.print("nhap a: ");
            a = inp.nextInt();
        }
        while(a<0 || a>9);
        switch(a){
            case 0:
                System.out.print(a + " đọc là Zero");
                break;
            case 1:
                System.out.print(a + " đọc là One");
                break;
            case 2:
                System.out.print(a + " đọc là Two");
                break;
            case 3:
                System.out.print(a + " đọc là Three");
                break;
            case 4:
                System.out.print(a + " đọc là Four");
                break;
            case 5:
                System.out.print(a + " đọc là Five");
                break;
            case 6:
                System.out.print(a + " đọc là Six");
                break;
            case 7:
                System.out.print(a + " đọc là Seven");
                break;
            case 8:
                System.out.print(a + " đọc là Eight");
                break;
            case 9:
                System.out.print(a + " đọc là Nice");
                break;                
        }
    }
}
