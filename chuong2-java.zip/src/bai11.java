import java.util.Scanner;
public class bai11 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        int thang, nam;
        System.out.print("Nhap thang: ");
        thang = inp.nextInt();
        if(thang>0 && thang <13){
            System.out.print("Nhap nam: ");
            nam = inp.nextInt();
            if(nam>0){
                if(nam%400==0 || nam%4==0 && nam%4 !=100){
                    System.out.print("Day la nam nhuan\n");
                    switch(thang){
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                        case 8:
                        case 10:
                        case 12:
                            System.out.print("Thang "+thang+" co 31 ngay");
                            break;
                        case 4:
                        case 6:
                        case 9:
                        case 11:
                            System.out.print("Thang "+thang+" co 30 ngay");
                            break;
                        case 2:
                            System.out.print("Thang "+thang+" co 29 ngay");
                            break;                            
                    }
                }
                else{
                    System.out.print("Day khong phai la nam nhuan\n");
                    switch(thang){
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                        case 8:
                        case 10:
                        case 12:
                            System.out.print("Thang "+thang+" co 31 ngay");
                            break;
                        case 4:
                        case 6:
                        case 9:
                        case 11:
                            System.out.print("Thang "+thang+" co 30 ngay");
                            break;
                        case 2:
                            System.out.print("Thang "+thang+" co 28 ngay");
                            break;                            
                    }                   
                }
            }
            else{
            System.out.print("Ban da nhap sai nam");                
            }
        }
        else{
            System.out.print("Ban da nhap sai thang");
        }
    }
}
