import java.util.Scanner;
public class bai12 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        int a;
        do{
            System.out.print("nhap a: ");
            a = inp.nextInt();
        }
        while(a<1 || a>9);
        for(int i=1; i<=10; i++){
            System.out.print(a+" x "+i+" = "+a*i+"\n");
        }
    }
}
