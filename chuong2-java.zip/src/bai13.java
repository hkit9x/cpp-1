public class bai13 {
    public static void main(String agrs[]){
        for(int i=1; i<=9; i++){
            System.out.print("\nBang cuu chuong "+i+":\n");            
            for(int j=1; j<=10; j++){
                System.out.print(i+" x "+j+" = "+j*i+"\n");
            }
        }
    }
}
