import java.util.Scanner;
public class bai14 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        int n, t;
        do{
            System.out.print("Nhap n:");
            n = inp.nextInt();
        }while(n<=0);
        int a[] = new int(n);
        for(int i = 0; i<n; i++){
            System.out.print("Nhap so thu "+(i+1)+" :");
            a[i] = inp.nextInt();            
        }
        for(int i = 0; i<n-1; i++){
            for(int j = 1; j<n; j++){
                if(a[i]>a[j]){
                    t=a[i];
                    a[i]=a[j];
                    a[j]=t;
                }
            }    
        }
        for(int i = 0; i<n; i++){
            System.out.print(a[i]+" ");
        }
        
    }
}
