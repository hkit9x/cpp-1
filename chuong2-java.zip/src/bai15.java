import java.util.Scanner;
public class bai15 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        System.out.print("nhap so hang, so cot cua 2 ma tran: ");
        int m = inp.nextInt();
        int n = inp.nextInt();
        int a[][] = new int[m][n];
        int b[][] = new int[m][n];
        int c[][] = new int[m][n];
        int d[][] = new int[m][n];
        System.out.print("nhap mang a");
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                System.out.print("nhap phan tu ["+i+"]["+j+"]: ");
                a[i][j] = inp.nextInt();
            }
        }
        System.out.print("nhap mang b");
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                System.out.print("nhap phan tu ["+i+"]["+j+"]: ");
                b[i][j] = inp.nextInt();
            }
        }
        System.out.print("Tong 2 ma tran:");
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                c[i][j] = a[i][j]+b[i][j];
            }
        }
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                System.out.print(c[i][j]+" ");
            }
            System.out.print("\n");            
        }
        System.out.print("Hieu 2 ma tran:");
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                d[i][j] = a[i][j]-b[i][j];
            }
        }
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                System.out.print(d[i][j]+" ");
            }
            System.out.print("\n");            
        }
        if(m==n){
        int e[][] = new int[m][m];            
            for(int i=0; i<m; i++){
                for(int j=0; j<m; j++){
                    e[i][j]=a
                }
                System.out.print("\n");            
            }            
        }
        
    }
}
