import java.util.Scanner;
public class bai16 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        int n;
        do{
            System.out.print("nhap n: ");
            n = inp.nextInt();
        }
        while(n<=0);
        inp.nextLine();
        String[] a = new String[n];

        for(int i=0; i<n; i++){
            a[i] = new String();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
            System.out.print("Nhap ho ten sinh vien "+(i)+"\n");
            a[i] = inp.nextLine();
        }
        for(int i=0; i<n; i++){
            System.out.print(a[i]+"\n");
        }
        
    }
}
