import java.util.Scanner;
public class bai17 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        String str;
        str = inp.nextLine();
        str.trim();
        String arr[] =str.split(" ");
        for(int i=0; i < arr.length; i++){
            System.out.print(arr[i]+"\n");
        }        
    }
}
