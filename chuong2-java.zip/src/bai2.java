import java.util.Scanner;

public class bai2 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        System.out.print("Nhap so a: ");
        int a = inp.nextInt();
        System.out.print("Nhap so b: ");
        int b = inp.nextInt();
        System.out.print("a + b = "+(a+b));
        System.out.print("\na - b = "+(a-b));
        System.out.print("\na * b = "+(a*b));
        try{
            System.out.print("\na/b = "+(a/b));
        }
        catch(Exception e){
                    System.out.print(e);
        }        
    }
}
