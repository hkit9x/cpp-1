public class bai3 {
    public static void main(String agrs[]){
        final double PI = 3.14;
        float r = 5;
        System.out.print("Chu vi: "+(2*PI*r));
        System.out.print("Dien tich: "+(PI*r*r));
    }
}
