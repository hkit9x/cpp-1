public class bai4 {
    public static void main(String agrs[]){
        int a, b, c;
        a = 5;
        b = 7;
        c = 15;
        System.out.print("Phan nguyen khi chia lan luot cac so "+a+", "+b+", "+c+" cho 2 la: "+a/2+", "+b/2+", "+c/2+"\n");
        System.out.print("Phan du khi chia lan luot cac so "+a+", "+b+", "+c+" cho 3 la: "+a%3+", "+b%3+", "+c%3+"\n");
        a++;
        b++;
        c++;
        System.out.print("cac so a b c sau khi tang len 1 = "+a+", "+b+", "+c+"\n");
        
    }
}
