import java.util.Scanner;
public class bai5 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        System.out.print("Nhap a, b, c: ");
        float a = inp.nextFloat();
        float b = inp.nextFloat();
        float c = inp.nextFloat();
        float x = (8*c-b)/2*a;
        System.out.print("x= "+x);
        System.out.print("\n (int) x= "+(int) x);        
    }
}
