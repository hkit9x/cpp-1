import static java.lang.Math.sqrt;
import java.util.Scanner;
public class bai6 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        float a, b, c;
        do{
            System.out.print("nhap a, b, c: ");
            a = inp.nextFloat();
            b = inp.nextFloat();
            c = inp.nextFloat();
        }
        while(a<=0 || b<=0 || c<=0);
        float p = (a+b+c)/2;
        float S = (float) sqrt(p*(p-a)*(p-b)*(p-c));
        System.out.print("Dien tich tam giac: "+S);
    }
}
