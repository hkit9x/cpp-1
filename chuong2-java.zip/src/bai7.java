import java.util.Scanner;
public class bai7 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        System.out.print("nhap a, b, c: ");
        float a,b,c;
        a = inp.nextFloat();
        b = inp.nextFloat();
        c = inp.nextFloat();
        if(a<=0 || b<= 0 || c<=0){
            System.out.print("Khong phai do dai 3 canh cua tam giac");
        }
        else
            if(a==b && b==c){
                System.out.print("tam giac deu");            
            }
            else
                if(a==b || b==c || c==a){
                    System.out.print("tam giac can");            
                }
                else
                    if(a*a == b*b+c*c || b*b == a*a+c*c || c*c == b*b+a*a){
                    System.out.print("tam giac vuong");            
                    }
                    else{
                        System.out.print("tam giac thuong");                        
                    }
    }
}
