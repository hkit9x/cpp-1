import static java.lang.Math.sqrt;
import java.util.Scanner;
public class bai8 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        System.out.print("Nhap a, b, c: ");
        float a, b, c;
        a = inp.nextFloat();
        b = inp.nextFloat();
        c = inp.nextFloat();
        if(a==0){
            System.out.print("Khong phai phuong trinh bac 2");
        }
        else{
            double delta = b*b-4*a*c;
            if(delta < 0 ){
                System.out.print("Phuong trinh vo nghiem");
            }
            else
                if(delta == 0){
                    System.out.print("phuong trinh co nghiem kep: "+(-b/2*a));
                }
                else{
                    float cdt = (float) sqrt(delta);
                    System.out.print("phuong trinh co 2 nghiem phan biet: x1= "+((-b+cdt)/(2*a))+" x2= "+((-b-cdt)/(2*a)));
                    
                }
                    
        }
             

    }
}
