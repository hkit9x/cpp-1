import java.util.Scanner;
public class bai9 {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
        System.out.print("Nhap a: ");
        int a = inp.nextInt();
        switch(a){
            case 1:
                System.out.print("Chu nhat");
                break;
            case 2:
                System.out.print("Thu Hai");
                break;
            case 3:
                System.out.print("Thu Ba");
                break;
            case 4:
                System.out.print("Thu Tu");
                break;
            case 5:
                System.out.print("Thu Nam");
                break;
            case 6:
                System.out.print("Thu Sau");
                break;
            case 7:
                System.out.print("Thu Bay");
                break;
            default:
                System.out.print("Ban da sai, chi duoc nhap so nguyen tu 1 toi 7");
        }
    }
}
