import java.util.Scanner;
public class bai {
    public static void main(String agrs[]){
        Scanner inp = new Scanner(System.in);
    }
}
