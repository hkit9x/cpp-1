/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai1;

/**
 *
 * @author PC-FIT
 */
public class HocSinh_Main {
    public static void main(String[] args) {
        HocSinh a, b;
        a = new HocSinh();
        b = new HocSinh();
        System.out.println("Nhap thong tin cho hoc sinh a: ");
        a.nhap();
        System.out.println("Nhap thong tin cho hoc sinh b: ");
        b.nhap();
        System.out.println("Nguoi co diem cao hon la: ");
        if(a.getDtb()>b.getDtb())
            a.xuat();
        else
            b.xuat();
    }
}
