/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class SinhVien {
    private String hoTen;
    private int namSinh;
    private float toan;
    private float ly;
    private float hoa;

    public SinhVien() {
    }

    public SinhVien(String hoTen, int namSinh, float toan, float ly, float hoa) {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.toan = toan;
        this.ly = ly;
        this.hoa = hoa;
    }
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap ho ten:");
        hoTen = scr.nextLine();
        System.out.println("Nhap nam sinh:");
        namSinh = scr.nextInt();
        System.out.println("Nhap diem toan:");
        toan = scr.nextFloat();
        System.out.println("Nhap diem ly:");
        ly = scr.nextFloat();
        System.out.println("Nhap diem hoa:");
        hoa = scr.nextFloat();
    }
    public void xuat(){
        System.out.println("Ho ten: "+hoTen);
        System.out.println("Nam sinh: "+namSinh);
        System.out.println("Diem toan: "+toan);
        System.out.println("Diem Ly: "+ly);
        System.out.println("Diem Hoa: "+hoa);
    }
    public float dtb(){
        return (toan+ly+hoa)/3;
    }
}
