/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class SinhVien_Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int n;
        do{
            System.out.println("Nhap n:");
            n = scr.nextInt();
        }while(n<=0);
        
        SinhVien ds[] = new SinhVien[n];
        for(int i=0; i<n; i++){
            System.out.println("Nhap thong tin cho sinh vien thu "+(i+1));
            ds[i] = new SinhVien();
            ds[i].nhap();
        }
        //sap xep
        System.out.println("Danh sach sinh vien sau khi sap xep");
        
        SinhVien tmp = new SinhVien();
        for(int i=0; i<n-1; i++)
            for(int j=1; j<n;j++){
                if(ds[i].dtb()>ds[j].dtb()){
                    tmp = ds[i];
                    ds[i]=ds[j];
                    ds[j]=tmp;
                }
            }
        for (int i = 0; i < n; i++) {
            ds[i].xuat();
        }
        //tim sv co dtb lon nhat
        
        float max = ds[0].dtb();
        for (int i = 1; i < n; i++) {
            if(ds[i].dtb()>max)
                max = ds[i].dtb();
        }
        System.out.println("Sinh vien co diem tb lon nhat la: ");
        for (int i = 0; i < n; i++) {
            if(ds[i].dtb()==max)
                ds[i].xuat();
        }
    }
}
