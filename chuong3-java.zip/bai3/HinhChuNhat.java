/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class HinhChuNhat {
    private float cd;
    private float cr;

    public HinhChuNhat(float cd, float cr) {
        this.cd = cd;
        this.cr = cr;
    }

    public HinhChuNhat() {
    }
    
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap chieu dai: ");
        cd = scr.nextFloat();
        System.out.println("Nhap chieu rong: ");
        cr = scr.nextFloat();
    }
    public float chuVi(){
        return (cd+cr)*2;
    }
    public float dienTich(){
        return cd*cr;
    }
    public void xuat(){
        System.out.println("Chieu dai: "+cd+"\tChieu rong: "+cr+"\tChu vi: "+this.chuVi()+"\tDien tich: "+this.dienTich());
    }
}
