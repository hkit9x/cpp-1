/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class HinhChuNhat_Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int n;
        do{
            System.out.println("Nhap n:");
            n = scr.nextInt();
        }while(n<=0);
        HinhChuNhat ds[] = new HinhChuNhat[n];
        for(int i=0; i<n; i++){
            System.out.println("Nhap hinh chu nhat thu "+(i+1));
            ds[i] = new HinhChuNhat();
            ds[i].nhap();
        }
        float max = ds[0].dienTich();
        for (int i = 1; i < n; i++)
            if(ds[i].dienTich()>max)
                max = ds[i].dienTich();
        System.out.println("Hinh chu nhat co dien tich lon nhat la: ");
        for (int i = 0; i < n; i++) {
            if(ds[i].dienTich() == max)
                ds[i].xuat();
        }

    }
}
