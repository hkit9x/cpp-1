/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class HangHoa {
    private String tenHang;
    private String maHang;
    private float gia;
    private int solg;
    private int gio;

    public HangHoa() {
    }

    public HangHoa(String tenHang, String maHang, float gia, int solg, int gio) {
        this.tenHang = tenHang;
        this.maHang = maHang;
        this.gia = gia;
        this.solg = solg;
        this.gio = gio;
    }
    
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap ten hang: ");
        tenHang = scr.nextLine();
        System.out.println("Nhap ma hang: ");
        maHang = scr.nextLine();
        System.out.println("Nhap gia ban: ");
        gia = scr.nextFloat();
        System.out.println("Nhap so luong: ");
        solg = scr.nextInt();
        System.out.println("Nhap gio ban: ");
        gio = scr.nextInt();
    }
    public void xuat(){
        System.out.println("Ten hang: "+tenHang+"\tMa hang: "+maHang+"\tgia: "+gia+"\tso luong: "+solg+"\tgio ban: "+gio);
    }
    public float tinhtien(){
        if(gio>=8 && gio<17)
            return (float) (gia*solg*0.05);
        return gia*solg;
    }
}
