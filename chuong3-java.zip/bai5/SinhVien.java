/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class SinhVien {
    private String hoTen;
    private int namSinh;
    private String lop;
    private float dtb;

    public SinhVien() {
    }

    public SinhVien(String hoTen, int namSinh, String lop, float dtb) {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.lop = lop;
        this.dtb = dtb;
    }
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap ho ten:");
        hoTen = scr.nextLine();
        System.out.println("Nhap nam sinh:");
        namSinh = scr.nextInt();
        System.out.println("Nhap diem trung binh:");
        dtb = scr.nextFloat();
    }
    public void xuat(){
        System.out.println("Ho ten: "+hoTen);
        System.out.println("Nam sinh: "+namSinh);
        System.out.println("Diem trung binh: "+dtb);
    }
    
}
