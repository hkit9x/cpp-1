/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class SinhVien_Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int n;
        do{
            System.out.println("Nhap n:");
            n = scr.nextInt();
        }while(n<=0);
        
        SinhVien ds[] = new SinhVien[n];
        for(int i=0; i<n; i++){
            System.out.println("Nhap thong tin cho sinh vien thu "+(i+1));
            ds[i] = new SinhVien();
            ds[i].nhap();
        }
        for (int i = 0; i < n; i++) {
            ds[i].xuat();
        }
    }
}
