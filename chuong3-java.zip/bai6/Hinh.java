/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

import static java.lang.Math.sqrt;
import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class Hinh {
    private float canh;

    public Hinh() {
    }
    public void nhap(){
        Scanner scr=new Scanner(System.in);
        System.out.println("Nhap canh: ");
        canh = scr.nextFloat();
    }
    public void xuat(){
        System.out.println("Canh: "+canh);
    }
    public float dienTich(float a){
        return a*a;
    }
    public float dienTich(float a, float b){
        return a*b;
    }
    public float dienTich(float a, float b, float c){
        float p = (float) ((a+b+c)/2);
        return (float) sqrt(p*(p-a)*(p-b)*(p-c));
    }
}
