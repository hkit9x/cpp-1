/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class Hinh_Main {
    public static void main(String[] args) {
        System.out.println("ban muon tinh dien tich hinh gi: ");
        System.out.println("\t1. Hinh Vuong");
        System.out.println("\t2. Hinh chu nhat");
        System.out.println("\t3. Hinh tam giac");
        Scanner scr = new Scanner(System.in);
        int chose = scr.nextInt();
        Hinh h = new Hinh();
        switch(chose){
            case 1:{
                System.out.println("Nhap chieu dai canh hinh vuong: ");
                float a = scr.nextFloat();
                System.out.println("Dien tich hinh vuong la: "+h.dienTich(a));        
            }
            break;
            case 2:{
                System.out.println("Nhap chieu dai 2 canh hinh chu nhat: ");
                float a = scr.nextFloat();
                float b = scr.nextFloat();
                System.out.println("Dien tich hinh chu nhat la: "+h.dienTich(a,b));        
            }
            break;
            case 3:{
                System.out.println("Nhap chieu dai 3 canh hinh tam giac: ");
                float a = scr.nextFloat();
                float b = scr.nextFloat();
                float c = scr.nextFloat();
                System.out.println("Dien tich hinh tam giac la: "+h.dienTich(a,b,c));        
            }
            break;
            default:
                System.out.println("Ban da lua chon sai");
            break;
        }
        
    }
}
