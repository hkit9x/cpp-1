/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class HangHoa {
    private String tenHang;
    private float gia;
    private int solg;
    private int giamgia;

    public HangHoa() {
    }
    
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap ten hang: ");
        tenHang = scr.nextLine();
        System.out.println("Nhap gia ban: ");
        gia = scr.nextFloat();
        System.out.println("Nhap so luong: ");
        solg = scr.nextInt();
        System.out.println("Nhap phan tram giam gia: ");
        giamgia = scr.nextInt();
    }
    public void xuat(){
        System.out.println("Ten hang: "+tenHang+"\tgia: "+gia+"\tso luong: "+solg+"\tphan tram giam gia: "+giamgia);
    }
    public float tinhtien(float gia, int solg){
        return gia*solg;
    }
    public float tinhtien(float gia, int solg, int giamgia){
        return gia*solg*giamgia/100;
    }

    public float getGia() {
        return gia;
    }

    public int getSolg() {
        return solg;
    }

    public int getGiamgia() {
        return giamgia;
    }
    
}
