/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class HangHoa_Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int n;
        do{
            System.out.println("Nhap n:");
            n = scr.nextInt();
        }while(n<=0);
        HangHoa ds[] = new HangHoa[n];
        for(int i=0; i<n; i++){
            System.out.println("Nhap hang hoa thu "+(i+1));
            ds[i] = new HangHoa();
            ds[i].nhap();
        }
        //tinh tong tien
        float tongtien=0;
        for (int i = 0; i < n; i++) {
            tongtien+=ds[i].tinhtien(ds[i].getGia(), ds[i].getSolg(), ds[i].getGiamgia());
            ds[i].xuat();
        }
        System.out.println("Tong tien: "+tongtien);
        
    }
}
