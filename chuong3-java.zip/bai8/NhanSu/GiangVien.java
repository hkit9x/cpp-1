/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8.NhanSu;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class GiangVien {
    private String hoTen;
    private int namSinh;
    private String chuyenMon;
    private String lop;

    public GiangVien() {
    }

    public GiangVien(String hoTen, int namSinh, String chuyenMon, String lop) {
        this.hoTen = hoTen;
        this.namSinh = namSinh;
        this.chuyenMon = chuyenMon;
        this.lop = lop;
    }
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap ho ten: ");
        hoTen = scr.nextLine();
        System.out.println("Nhap nam sinh: ");
        namSinh = scr.nextInt();
        System.out.println("Nhap chuyen mon: ");
        chuyenMon = scr.nextLine();
        System.out.println("Nhap lop day: ");
        lop = scr.nextLine();        
    }
    public void xuat(){
        System.out.println("ho ten: "+hoTen);
        System.out.println("nam sinh: "+namSinh);
        System.out.println("Chuyen mom: "+chuyenMon);
        System.out.println("Lop day: "+lop);
    }

    public String getLop() {
        return lop;
    }
    
}
