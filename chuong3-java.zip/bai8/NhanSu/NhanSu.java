/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8.NhanSu;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class NhanSu {
    public static void main(String[] args) {
                Scanner scr = new Scanner(System.in);
        int n, m;
        do{
            System.out.println("Nhap n:");
            n = scr.nextInt();
        }while(n<=0);
        
        SinhVien dssv[] = new SinhVien[n];
        for(int i=0; i<n; i++){
            System.out.println("Nhap thong tin cho sinh vien thu "+(i+1));
            dssv[i] = new SinhVien();
            dssv[i].nhap();
        }

        do{
            System.out.println("Nhap m:");
            m = scr.nextInt();
        }while(n<=0);
        
        GiangVien dsgv[] = new GiangVien[m];
        for(int i=0; i<n; i++){
            System.out.println("Nhap thong tin cho GiangVien thu "+(i+1));
            dsgv[i] = new GiangVien();
            dsgv[i].nhap();
        }
        System.out.println("Nhap ten sinh vien: ");
        String tsv = scr.nextLine();
        int point = 0;
        for (int i = 0; i < n; i++) {
            if(tsv.equalsIgnoreCase( dssv[i].getHoTen() ) )
                point = i;
        }
        System.out.println("Danh sach giang vien co day sinh vien nay la: ");
        for (int i = 0; i < m; i++) {
            if(dssv[point].getLop().equalsIgnoreCase(dsgv[i].getLop()))
                dsgv[i].xuat();
        }
        //chua xong
        //be to continue

    }
    
}
