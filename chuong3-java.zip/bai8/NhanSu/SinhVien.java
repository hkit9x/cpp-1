/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8.NhanSu;

import java.util.Scanner;

/**
 *
 * @author PC-FIT
 */
public class SinhVien {
    private String hoTen;
    private String lop;
    private float toan;
    private float ly;
    private float hoa;

    public SinhVien() {
    }

    public SinhVien(String hoTen, String lop, float toan, float ly, float hoa) {
        this.hoTen = hoTen;
        this.lop = lop;
        this.toan = toan;
        this.ly = ly;
        this.hoa = hoa;
    }
    public void nhap(){
        Scanner scr = new Scanner(System.in);
        System.out.println("Nhap ho ten:");
        hoTen = scr.nextLine();
        System.out.println("Nhap lop:");
        lop = scr.nextLine();
        System.out.println("Nhap diem toan:");
        toan = scr.nextFloat();
        System.out.println("Nhap diem ly:");
        ly = scr.nextFloat();
        System.out.println("Nhap diem hoa:");
        hoa = scr.nextFloat();
    }
    public void xuat(){
        System.out.println("Ho ten: "+hoTen);
        System.out.println("lop: "+lop);
        System.out.println("Diem toan: "+toan);
        System.out.println("Diem Ly: "+ly);
        System.out.println("Diem Hoa: "+hoa);
    }
    public float dtb(){
        return (toan+ly+hoa)/3;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getLop() {
        return lop;
    }
    
}
